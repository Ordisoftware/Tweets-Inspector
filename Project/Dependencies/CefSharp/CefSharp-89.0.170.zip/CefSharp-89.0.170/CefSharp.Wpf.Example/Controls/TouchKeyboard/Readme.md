Code in this folder is adapted from https://github.com/Microsoft/WPF-Samples/tree/master/Input%20and%20Commands/TouchKeyboard/TouchKeyboardNotifier

Licensed under an MIT license, see https://github.com/Microsoft/WPF-Samples/blob/master/LICENSE

The files aren't included in the .csproj file intentially as they require the Windows 10 SDK

It is reccomended that you obtain and use the https://github.com/Microsoft/WPF-Samples/tree/master/Input%20and%20Commands/TouchKeyboard/TouchKeyboardNotifier
solution provided by Microsoft. It has more advanced features including TouchKeyboardAwareDecorator, which can be used
to resize your window when the touch keyboard is visible. Please read https://github.com/Microsoft/WPF-Samples/blob/master/Input%20and%20Commands/TouchKeyboard/TouchKeyboardNotifier/Readme.md

